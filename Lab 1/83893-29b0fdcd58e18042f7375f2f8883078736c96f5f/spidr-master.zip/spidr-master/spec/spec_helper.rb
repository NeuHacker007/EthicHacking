require 'rspec'
require 'spidr/version'

include Spidr
