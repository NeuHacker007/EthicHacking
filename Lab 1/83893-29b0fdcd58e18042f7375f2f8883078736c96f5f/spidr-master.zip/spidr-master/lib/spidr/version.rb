module Spidr
  # Spidr version
  VERSION = '0.5.0'
end
