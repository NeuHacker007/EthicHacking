require 'spidr/extensions/uri'
